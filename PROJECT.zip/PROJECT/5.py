# RSNA Pneumonia Detection - Faster R-CNN 객체 탐지 전체 파이프라인 (Target 오류 수정 포함)

import os
import pandas as pd
import numpy as np
import pydicom
import cv2
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision
from torchvision.models.detection import fasterrcnn_resnet50_fpn, FasterRCNN_ResNet50_FPN_Weights
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_fscore_support

# CUDA 확인
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# CSV 불러오기
class_info = pd.read_csv('./kaggle/rsna-pneumonia-detection-challenge/stage_2_detailed_class_info.csv')
bbox_info = pd.read_csv('./kaggle/rsna-pneumonia-detection-challenge/stage_2_train_labels.csv')

# 병합 및 경로 추가
pneumonia = pd.merge(class_info, bbox_info, on='patientId')
pneumonia['bbox'] = pneumonia[['x','y','height','width']].apply(lambda x: '-'.join(str(i) for i in x), axis=1)
pneumonia['image_path'] = pneumonia['patientId'].apply(lambda x: f"./kaggle/rsna-pneumonia-detection-challenge/stage_2_train_images/{x}.dcm")

# PA View 필터링
pa_indices = []
for i in tqdm(range(len(pneumonia))):
    try:
        dcm = pydicom.dcmread(pneumonia['image_path'][i], stop_before_pixels=True)
        if hasattr(dcm, 'ViewPosition') and dcm.ViewPosition == 'PA':
            pa_indices.append(i)
    except:
        continue

pneumonia = pneumonia.loc[pa_indices].reset_index(drop=True)

# bbox 파싱
bbox_split = pneumonia['bbox'].dropna().str.split('-', expand=True)
bbox_split.columns = ['x', 'y', 'height', 'width']
bbox_split = bbox_split.astype(float)
pneumonia.loc[bbox_split.index, ['x','y','height','width']] = bbox_split

# Target 존재 확인 및 결측 제거
pneumonia = pneumonia[pneumonia['Target'].notnull()]
pneumonia['Target'] = pneumonia['Target'].astype(int)

# 양성/음성 분리
pos_df = pneumonia[(pneumonia['Target'] == 1) & pneumonia[['x','y','height','width']].notnull().all(axis=1)]
neg_df = pneumonia[pneumonia['Target'] == 0].sample(n=2649, random_state=42)
df = pd.concat([pos_df, neg_df], ignore_index=True)

# 학습/검증 분리
train_df, val_df = train_test_split(df, test_size=0.2, stratify=df['Target'], random_state=42)

# Dataset 정의
class PneumoniaDetectionDataset(Dataset):
    def __init__(self, df):
        self.df = df.reset_index(drop=True)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        dcm = pydicom.dcmread(row['image_path'])
        img = dcm.pixel_array
        orig_h, orig_w = img.shape

        img = cv2.resize(img, (224, 224))
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        img = torch.tensor(img / 255.0, dtype=torch.float32).permute(2, 0, 1)

        if row['Target'] == 1:
            scale_x = 224 / orig_w
            scale_y = 224 / orig_h
            x1 = row['x'] * scale_x
            y1 = row['y'] * scale_y
            x2 = (row['x'] + row['width']) * scale_x
            y2 = (row['y'] + row['height']) * scale_y
            boxes = torch.tensor([[x1, y1, x2, y2]], dtype=torch.float32)
            labels = torch.tensor([1], dtype=torch.int64)
        else:
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.int64)

        return img, {"boxes": boxes, "labels": labels}

# collate_fn
collate_fn = lambda x: tuple(zip(*x))

# Dataloader
train_loader = DataLoader(PneumoniaDetectionDataset(train_df), batch_size=2, shuffle=True, collate_fn=collate_fn)
val_loader   = DataLoader(PneumoniaDetectionDataset(val_df), batch_size=2, shuffle=False, collate_fn=collate_fn)

# 모델 정의
model = fasterrcnn_resnet50_fpn(weights=FasterRCNN_ResNet50_FPN_Weights.DEFAULT)
in_feat = model.roi_heads.box_predictor.cls_score.in_features
model.roi_heads.box_predictor = torchvision.models.detection.faster_rcnn.FastRCNNPredictor(in_feat, 2)
model.to(device)

# 옵티마이저, 스케줄러
params = [p for p in model.parameters() if p.requires_grad]
optimizer = torch.optim.Adam(params, lr=1e-4)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=2)

# EarlyStopping
class EarlyStopping:
    def __init__(self, patience=3):
        self.patience = patience
        self.counter = 0
        self.best_loss = float('inf')
        self.early_stop = False

    def __call__(self, val_loss):
        if val_loss < self.best_loss:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True

early_stopping = EarlyStopping(patience=3)

# 학습
os.makedirs("models", exist_ok=True)
epoch_logs = []
num_epochs = 20

for epoch in range(num_epochs):
    model.train()
    train_losses, train_y_true, train_y_pred = [], [], []

    for images, targets in tqdm(train_loader):
        images = [i.to(device) for i in images]
        targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
        loss_dict = model(images, targets)
        loss = sum(loss for loss in loss_dict.values())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        train_losses.append(loss.item())

        with torch.no_grad():
            preds = model(images)
            for p, t in zip(preds, targets):
                pred_lbl = p['labels'][p['scores'] > 0.5]
                train_y_pred.append(1 if len(pred_lbl) > 0 else 0)
                train_y_true.append(1 if len(t['labels']) > 0 else 0)

    train_loss = np.mean(train_losses)
    train_f1 = precision_recall_fscore_support(train_y_true, train_y_pred, average='binary', zero_division=0)[2]

    # === 검증 ===
    model.eval()
    val_losses, val_y_true, val_y_pred = [], [], []
    with torch.no_grad():
        for images, targets in val_loader:
            images = [i.to(device) for i in images]
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
            loss_dict = model(images, targets)
            loss = sum(loss for loss in loss_dict.values())
            val_losses.append(loss.item())

            preds = model(images)
            for p, t in zip(preds, targets):
                pred_lbl = p['labels'][p['scores'] > 0.5]
                val_y_pred.append(1 if len(pred_lbl) > 0 else 0)
                val_y_true.append(1 if len(t['labels']) > 0 else 0)

    val_loss = np.mean(val_losses)
    val_f1 = precision_recall_fscore_support(val_y_true, val_y_pred, average='binary', zero_division=0)[2]

    print(f"[Epoch {epoch+1}] Train Loss: {train_loss:.4f} | Train F1: {train_f1:.4f} | Val Loss: {val_loss:.4f} | Val F1: {val_f1:.4f}")

    epoch_logs.append({
        'epoch': epoch+1,
        'train_loss': train_loss,
        'train_f1': train_f1,
        'val_loss': val_loss,
        'val_f1': val_f1
    })

    scheduler.step(val_loss)
    early_stopping(val_loss)

    if val_loss < early_stopping.best_loss:
        torch.save(model.state_dict(), "models/best_model.pth")
        print("\U0001F4E6 Best model saved.")

    if early_stopping.early_stop:
        print("Early stopping triggered.")
        break

# 로그 저장
pd.DataFrame(epoch_logs).to_csv("training_metrics.csv", index=False)

# 시각화 예측 결과
model.load_state_dict(torch.load("models/best_model.pth"))
model.eval()
img, target = PneumoniaDetectionDataset(val_df)[0]
with torch.no_grad():
    pred = model([img.to(device)])

img_np = img.permute(1,2,0).cpu().numpy()
plt.imshow(img_np)
for box in pred[0]['boxes']:
    x1, y1, x2, y2 = box.cpu().numpy()
    rect = plt.Rectangle((x1, y1), x2 - x1, y2 - y1, fill=False, color='r')
    plt.gca().add_patch(rect)
plt.title("Predicted BBox")
plt.axis('off')
plt.show()