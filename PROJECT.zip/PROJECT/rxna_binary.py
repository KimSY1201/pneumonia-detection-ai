from pathlib import Path
import pydicom
import numpy as np
import cv2
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.notebook import tqdm
import os
import glob
import torch
from torch.utils.data import TensorDataset, DataLoader
import torchvision
from torchmetrics.classification import BinaryF1Score, BinaryAUROC
import torch.nn as nn

detail_class = pd.read_csv('./kaggle/rsna-pneumonia-detection-challenge/stage_2_detailed_class_info.csv')

bbox_info = pd.read_csv('./kaggle/rsna-pneumonia-detection-challenge/stage_2_train_labels.csv')

dicom_dir = './kaggle/rsna-pneumonia-detection-challenge/stage_2_train_images'

num_dicom = os.listdir(dicom_dir)

pneumonia = pd.merge(detail_class, bbox_info, on='patientId', how='inner')

pneumonia['bbox'] = pneumonia[['x', 'y', 'height', 'width']].apply(lambda x: '-'.join(str(i) for i in x), axis=1)

path = './kaggle/rsna-pneumonia-detection-challenge/stage_2_train_images/*.dcm'

images = os.listdir('./kaggle/rsna-pneumonia-detection-challenge/stage_2_train_images')

pneumonia['image_path'] = ''

for i in range(len(pneumonia)):
    patient_id = pneumonia['patientId'][i]
    image_path = os.path.join('./kaggle/rsna-pneumonia-detection-challenge/stage_2_train_images', patient_id + '.dcm')
    pneumonia['image_path'][i] = image_path

random_patient_id = pneumonia['patientId'].sample().values[0]
dicom_data = pydicom.dcmread(image_path)

from tqdm import tqdm 

pa_indices = []

for i in tqdm(range(len(pneumonia))): 
    try:
        dcm = pydicom.dcmread(pneumonia['image_path'][i], stop_before_pixels=True)
        if 'ViewPosition' in dcm and dcm.ViewPosition == 'PA':
            pa_indices.append(i)
    except Exception as e:
        print(f"Error reading file at index {i}: {e}")

pneumonia_pa = pneumonia.loc[pa_indices].reset_index(drop=True)

def read_and_resize_images_tensor(pneumonia_pa):
    images = []
    labels = []

    for i in range(len(pneumonia_pa)):
        image_path = pneumonia_pa['image_path'][i]
        target = pneumonia_pa['Target'][i]

        # DICOM 이미지 불러오기
        dicom_data = pydicom.dcmread(image_path)
        img = dicom_data.pixel_array

        # 이미지 크기 224x224로 조정 및 채널 3개로 확장
        img = cv2.resize(img, (224, 224))
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

        # 정규화 (0~1), Tensor로 변환, shape: (3, 224, 224)
        img_tensor = torch.tensor(img / 255.0, dtype=torch.float32).permute(2, 0, 1)

        # Target 값 (0 or 1) → float tensor
        label_tensor = torch.tensor(target, dtype=torch.float32)

        images.append(img_tensor)
        labels.append(label_tensor)

    return torch.stack(images), torch.stack(labels)

X, y = read_and_resize_images_tensor(pneumonia_pa)

from sklearn.model_selection import train_test_split
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

from torch.utils.data import TensorDataset, DataLoader
train_dataset = TensorDataset(X_train, y_train)
val_dataset   = TensorDataset(X_val, y_val)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_loader   = DataLoader(val_dataset, batch_size=32, shuffle=False)

# 저장 폴더 생성
os.makedirs('models', exist_ok=True)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

from torchvision import models

model = models.resnet50(pretrained=True)

# 사전 학습된 ResNet-50 불러오기
# 마지막 FC 레이어 수정 (이진 분류 → 출력 1개)
model.fc = nn.Linear(model.fc.in_features, 1)
model = model.to(device)

# 손실함수, 옵티마이저, 스케줄러, metric
criterion = nn.BCEWithLogitsLoss()
params = [p for p in model.parameters() if p.requires_grad]
optimizer = torch.optim.Adam(params, lr=1e-4)
scheduler = scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer,
    mode='min',
    patience=2,
    factor=0.5
)
# Metrics
f1_metric = BinaryF1Score().to(device)
auc_metric = BinaryAUROC().to(device)

# EarlyStopping 변수
early_stop_patience = 5
best_val_loss = float('inf')
patience_counter = 0

from tqdm import tqdm 

num_epochs = 30
train_losses, val_losses = [], []
val_f1s, val_aucs = [], []

for epoch in tqdm(range(num_epochs)):
    f1_metric.reset()
    auc_metric.reset()
    model.train()
    running_loss = 0.0
    
    for images, labels in train_loader:
        images = images.to(device)
        labels = labels.to(device).unsqueeze(1)

        outputs = model(images)
        loss = criterion(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * images.size(0)

    epoch_train_loss = running_loss / len(train_loader.dataset)
    train_losses.append(epoch_train_loss)

    # === 검증 ===
    model.eval()
    val_loss = 0.0
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for images, labels in val_loader:
            images = images.to(device)
            labels = labels.to(device).unsqueeze(1)

            outputs = model(images)
            loss = criterion(outputs, labels)
            val_loss += loss.item() * images.size(0)

            all_preds.append(torch.sigmoid(outputs))
            all_labels.append(labels)

    epoch_val_loss = val_loss / len(val_loader.dataset)
    val_losses.append(epoch_val_loss)

    # === Metrics 계산 ===
    all_preds = torch.cat(all_preds)
    all_labels = torch.cat(all_labels)

    f1 = f1_metric(all_preds, all_labels)
    auc = auc_metric(all_preds, all_labels)

    val_f1s.append(f1.item())
    val_aucs.append(auc.item())

    print(f"[Epoch {epoch+1}] Train Loss: {epoch_train_loss:.4f} | Val Loss: {epoch_val_loss:.4f} | F1: {f1:.4f} | AUC: {auc:.4f}")

    # === EarlyStopping ===
    if epoch_val_loss < best_val_loss:
        best_val_loss = epoch_val_loss
        patience_counter = 0
        torch.save(model.state_dict(), f"models/best_binary_model_epoch_{epoch+1}.pth")
        print(" 모델 저장 (validation loss 개선)")
    else:
        patience_counter += 1
        if patience_counter >= early_stop_patience:
            print(" Early stopping triggered")
            break

    # === Scheduler 업데이트 ===
    scheduler.step(epoch_val_loss)
