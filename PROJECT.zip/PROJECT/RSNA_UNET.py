# RSNA Pneumonia Detection - Faster R-CNN 객체 탐지 전체 파이프라인

# 라이브러리 임포트
from pathlib import Path
import os
import pandas as pd
import numpy as np
import pydicom
import cv2
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from sklearn.model_selection import train_test_split
from torchvision import transforms
from tqdm import tqdm
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_fscore_support

# CUDA 사용 가능 여부 확인
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# CSV 불러오기
detail_class = pd.read_csv(r'./kaggle/rsna-pneumonia-detection-challenge/stage_2_detailed_class_info.csv')
bbox_info = pd.read_csv(r'./kaggle/rsna-pneumonia-detection-challenge/stage_2_train_labels.csv')

# 병합 및 경로 지정
pneumonia = pd.merge(detail_class, bbox_info, on='patientId', how='inner')
pneumonia['bbox'] = pneumonia[['x', 'y', 'height', 'width']].apply(lambda x: '-'.join(str(i) for i in x), axis=1)
pneumonia['image_path'] = pneumonia['patientId'].apply(
    lambda pid: f"./kaggle/rsna-pneumonia-detection-challenge/stage_2_train_images/{pid}.dcm"
)

# PA View만 필터링
pa_indices = []
for i in tqdm(range(len(pneumonia))):
    try:
        dcm = pydicom.dcmread(pneumonia['image_path'][i], stop_before_pixels=True)
        if 'ViewPosition' in dcm and dcm.ViewPosition == 'PA':
            pa_indices.append(i)
    except Exception as e:
        print(f"Error reading file at index {i}: {e}")

pneumonia_pa = pneumonia.loc[pa_indices].reset_index(drop=True)
df = pneumonia_pa.copy()

# bbox 문자열 → 숫자 파싱
if 'bbox' in df.columns and not df['bbox'].dropna().empty:
    bbox_split = df['bbox'].dropna().str.split('-', expand=True)
    if bbox_split.shape[1] == 4:
        bbox_split.columns = ['x', 'y', 'height', 'width']
        bbox_split = bbox_split.astype(float)
        df.loc[bbox_split.index, ['x', 'y', 'height', 'width']] = bbox_split

# Target==1 은 bbox 정보 필수
df_pos = df[(df['Target'] == 1) & df[['x', 'y', 'height', 'width']].notnull().all(axis=1)]
df_neg = df[df['Target'] == 0]
df_clean = pd.concat([df_pos, df_neg], ignore_index=True)

print(f"총 샘플 수: {len(df_clean)}, 양성: {len(df_pos)}, 음성: {len(df_neg)}")

# 학습/검증 분할
train_df, val_df = train_test_split(df_clean, test_size=0.2, stratify=df_clean['Target'], random_state=42)

# Dataset 클래스 정의
class PneumoniaDetectionDataset(Dataset):
    def __init__(self, df, transform=None):
        self.df = df.reset_index(drop=True)
        self.transform = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        try:
            row = self.df.iloc[idx]
            dcm = pydicom.dcmread(row['image_path'])
            img = dcm.pixel_array
            orig_h, orig_w = img.shape

            img = cv2.resize(img, (224, 224))
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
            img = torch.tensor(img / 255.0, dtype=torch.float32).permute(2, 0, 1)

            if row['Target'] == 1:
                scale_x = 224 / orig_w
                scale_y = 224 / orig_h
                x1 = row['x'] * scale_x
                y1 = row['y'] * scale_y
                x2 = (row['x'] + row['width']) * scale_x
                y2 = (row['y'] + row['height']) * scale_y
                boxes = torch.tensor([[x1, y1, x2, y2]], dtype=torch.float32)
                labels = torch.tensor([1], dtype=torch.int64)
            else:
                boxes = torch.zeros((0, 4), dtype=torch.float32)
                labels = torch.zeros((0,), dtype=torch.int64)

            return img, {'boxes': boxes, 'labels': labels}

        except Exception as e:
            print(f" Error at idx {idx}: {e}")
            return self.__getitem__((idx + 1) % len(self))

# DataLoader 준비
def collate_fn(batch):
    return tuple(zip(*batch))

train_dataset = PneumoniaDetectionDataset(train_df)
val_dataset   = PneumoniaDetectionDataset(val_df)

train_loader = DataLoader(train_dataset, batch_size=2, shuffle=True, collate_fn=collate_fn)
val_loader   = DataLoader(val_dataset, batch_size=2, shuffle=False, collate_fn=collate_fn)

from torchvision.models.detection import fasterrcnn_resnet50_fpn, FasterRCNN_ResNet50_FPN_Weights

# 모델 정의
weights = FasterRCNN_ResNet50_FPN_Weights.DEFAULT
model = fasterrcnn_resnet50_fpn(weights=weights)
in_features = model.roi_heads.box_predictor.cls_score.in_features
model.roi_heads.box_predictor = torchvision.models.detection.faster_rcnn.FastRCNNPredictor(in_features, num_classes=2)
model = model.to(device)

params = [p for p in model.parameters() if p.requires_grad]
optimizer = torch.optim.Adam(params, lr=1e-4)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=2)

# 조기 종료
class EarlyStopping:
    def __init__(self, patience=3):
        self.patience = patience
        self.counter = 0
        self.best_loss = float('inf')
        self.early_stop = False

    def __call__(self, val_loss):
        if val_loss < self.best_loss:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True

early_stopping = EarlyStopping(patience=3)

# 학습 루프
num_epochs = 5
for epoch in range(num_epochs):
    model.train()
    total_loss = 0.0
    for images, targets in tqdm(train_loader):
        images = [img.to(device) for img in images]
        targets = [{k: v.to(device) for k, v in t.items()} for t in targets]

        loss_dict = model(images, targets)
        losses = sum(loss for loss in loss_dict.values())

        optimizer.zero_grad()
        losses.backward()
        optimizer.step()

        total_loss += losses.item()

    print(f"[Epoch {epoch+1}] Loss: {total_loss:.4f}")
    scheduler.step(total_loss)
    early_stopping(total_loss)

    if total_loss < early_stopping.best_loss:
        torch.save(model.state_dict(), f"best_fasterrcnn_epoch{epoch+1}.pth")

    if early_stopping.early_stop:
        print("Early stopping triggered.")
        break

# 결과 시각화 및 평가
model.eval()
image, target = val_dataset[0]
with torch.no_grad():
    prediction = model([image.to(device)])

# 시각화
img_np = image.permute(1, 2, 0).cpu().numpy()
plt.imshow(img_np)
for box in prediction[0]['boxes']:
    x1, y1, x2, y2 = box.cpu().numpy()
    rect = plt.Rectangle((x1, y1), x2 - x1, y2 - y1, fill=False, edgecolor='r', linewidth=2)
    plt.gca().add_patch(rect)
plt.title("Predicted Bounding Boxes")
plt.axis('off')
plt.show()

# F1 & Recall 계산
pred_boxes = prediction[0]['boxes'].cpu().numpy()
pred_scores = prediction[0]['scores'].cpu().numpy()
pred_labels = prediction[0]['labels'].cpu().numpy()
threshold = 0.5
pred_filtered = pred_labels[pred_scores > threshold]
gt_labels = target['labels'].cpu().numpy()
y_true = [1 if len(gt_labels) > 0 else 0]
y_pred = [1 if len(pred_filtered) > 0 else 0]
precision, recall, f1, _ = precision_recall_fscore_support(y_true, y_pred, average='binary', zero_division=0)
print(f"F1-score: {f1:.4f}, Recall: {recall:.4f}")
